function [r, ar]= rsquare(y,yest,df)

n= length(y);
ar = 1 - sum((y - yest).^2)/sum((y - mean(y)).^2);

r = 1 - (sum((y - yest).^2)/sum((y - mean(y)).^2)) .* ((n-1-df)/(n-1));

end