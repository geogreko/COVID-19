clear; close all; clc


% Italy= xlsread('Italy.xlsx');
% Spain= xlsread('Spain.xlsx');
% France= xlsread('France.xlsx');	
% Netherland= xlsread('Netherland.xlsx');		
% Switzerland= xlsread('Switzerland.xlsx');
% Germany= xlsread('Germany.xlsx');		
% Portugal= xlsread('Portugal.xlsx');		
% UK= xlsread('UK.xlsx');
% Greece= xlsread('Greece.xlsx');		
% Ireland= xlsread('Ireland.xlsx');	
Italy= readtable('Italy.xlsx');
Spain= readtable('Spain.xlsx'); 
France= readtable('France.xlsx');	
Netherland= readtable('Netherland.xlsx');		
Switzerland= readtable('Switzerland.xlsx');
Germany= readtable('Germany.xlsx');		
Portugal= readtable('Portugal.xlsx');		
UK= readtable('UK.xlsx');
Greece= readtable('Greece.xlsx');		
Ireland= readtable('Ireland.xlsx');

dit= datenum(Italy.Var1); 
dsp= datenum(Spain.Var1); 
dfr= datenum(France.Var1); 
dne= datenum(Netherland.Var1); 
dsw= datenum(Switzerland.Var1); 
dpo= datenum(Portugal.Var1); 
dge= datenum(Germany.Var1);
dgr= datenum(Greece.Var1);  
dir= datenum(Ireland.Var1); 
duk= datenum(UK.Var1); 

figure, 
subplot(2,2,1),
plot(dsp,Spain.Var2,'ko'); hold on;
plot(dsp,Spain.Var3,'b'); hold on;
plot(dsp,Spain.Var4,'r'); hold off;
% set(gca, 'XTick',1:size(dsp,1), 'XTickLabel',dsp);
datetick('x', 'dd mmm yy', 'keepticks')
title('Spain')
legend('actual','logistic','rational')

subplot(2,2,2),
plot(dge,Germany.Var2,'ko'); hold on;
plot(dge,Germany.Var3,'b'); hold on;
plot(dge,Germany.Var4,'r'); hold off;
title('Germany')
legend('actual','logistic','rational')
datetick('x', 'dd mmm yy', 'keepticks')

subplot(2,2,3),
% plot(duk,UK.Var4,'k'); hold on;
plot(dsp,Spain.Var4,'b'); hold on;
plot(dfr,France.Var4,'r'); hold on;
plot(dir,Ireland.Var4,'g'); hold on;
plot(dit,Italy.Var4,'c'); hold on;
plot(dne,Netherland.Var4,'y'); hold on;
plot(dsw,Switzerland.Var4,'m'); hold off;
title('Late Responses')
legend('UK','Spain','France','Ireland','Italy','Netherland','Switzerland');
datetick('x', 'dd mmm yy', 'keepticks')
subplot(2,2,4),
plot(dge,Germany.Var4,'k'); hold on;
plot(dgr,Greece.Var4,'b'); hold on;
plot(dpo,Portugal.Var4,'r'); hold off;
title('Early Responses')
legend('Germany','Greece','Portugal');
datetick('x', 'dd mmm yy', 'keepticks')



% f = figure;
% u = f.Units;
% 
% f.Units = 'centimeters';
% 
% x0=10;
% 
% y0=5;
% 
% width=12;
% 
% height=8;
% 
% set(gcf,'position',[x0,y0,width,height]);
% 
%  
% 
% xlabel/ylabel : 'FontSize',9
% 
% grid on
% 
% legend/XTickLabel : 'FontSize',7  (for the dates formatted as: April 20 at a 5 days interval - rotated at some degree if needed)
% 
% legend boxoff;