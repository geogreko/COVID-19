clear; close all; clc

% Modelling deaths using the Logistic and Rational 
% 
% References:
% https://doi.org/10.1098/rsif.2020.0494
data= xlsread('data.xlsx');

[na, nc]= size(data);

for cc= 1:nc
    
    jj=1;
    for ii=1:na
        if data(ii,cc)>=10
            mea_cases(jj,1)= data(ii,cc); time(jj,1)= jj; jj=jj+1;
        end
    end
    nt= time(end);
    
    disp('Logistic model:')
    k =  0.1 ; 
    b = 8;		
    yf = 30;
    lgp0=[yf, b, k];
    lg_fun= @(lgp) lgp(1)*(ones(nt,1)./(1+lgp(2)*exp(-lgp(3)*time)));
    lg_obj = @(lgp) (sum(abs(lg_fun(lgp)-mea_cases)));

    lgRsq0=-1000; opts1=  optimset('display','off');
    for it=1:3000
        lgp= fminsearchbnd3(lg_obj, lgp0, [0 0 0], [1e6 1e3 1],opts1);
        time0=[1:1000]';
        lg_fun0= @(lgp) lgp(1)*(ones(1000,1)./(1+lgp(2)*exp(-lgp(3)*time0)));
        gr= gradient(lg_fun0(lgp)); 
        [lgRsq, ~]= rsquare(mea_cases,lg_fun(lgp),3);
        if lgRsq > lgRsq0 && gr(end)<1
            lg_b = lgp(2);
            lg_k = lgp(3);
            lg_yf = lgp(1);
            lgRsq0= lgRsq;
        end
        lgp0=[5*mea_cases(end)*rand, 50*rand, 0.1+0.3*rand];
    end

    lgp(3)=lg_k;
    lgp(2)=lg_b;
    lgp(1)=lg_yf;
    
    % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
    display('Goodness of fit tests for the Logistic model')
    [lgRsq, ~]= rsquare(mea_cases,lg_fun(lgp),3)
    lgRMSE = sqrt(mean((mea_cases - lg_fun(lgp)).^2));
    % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

    figure, plot(time, mea_cases,'k','LineWidth',1.5)
    hold on;
    plot(time, lg_fun(lgp),'g','LineWidth',1.5)
    hold on;

    display('Estimated parameters for the Logistic model')
    lg_b = lgp(3)
    lg_k = lgp(2)
    lg_yf = lgp(1)
    

    Results(:,1)= [{'time'}; num2cell(time)];
    Results(:,2)= [{'mea_cases'}; num2cell(mea_cases)];
    Results(:,3)= [{'logistic'}; num2cell(lg_fun(lgp))];
    Results(2,9)= [{'logistic'}];
    Results(1,10)= [{'Rsquare'}];
    Results(2,10)= num2cell(lgRsq);
    Results(1,11)= [{'RMSE'}];
    Results(2,11)= num2cell(lgRMSE);
    Results(1,15)= [{'logistic'}];
    Results(2,14)= [{'Nf'}];
    Results(3,14)= [{'b'}];
    Results(4,14)= [{'k'}];
    Results(2:4,15)= num2cell(lgp');
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
    disp('Rational:')
    c = 0.01;
    k= 9;
    b= 250;
    Nf= 80000;
    Ratp0=[Nf, b, k, c];
    Rat_fun= @(Ratp) Ratp(1)*(ones(nt,1)./(1+Ratp(2).*power((1+Ratp(4)*time),-Ratp(3))));
    Rat_obj = @(Ratp) sum(sum(abs(Rat_fun(Ratp)-mea_cases)));

    RatRsq0=-10000; opts1=  optimset('display','off');
    for it=1:3000
        Ratp= fminsearchbnd3(Rat_obj, Ratp0, [0 0 0 0.0], [1e6 1e3 10 1],opts1);
        [RatRsq, ~]= rsquare(mea_cases,Rat_fun(Ratp),5);
        time0=[1:1000]';
        Rat_fun0= @(Ratp) Ratp(1)*(ones(1000,1)./(1+Ratp(2).*power((1+Ratp(4)*time0),-Ratp(3))));
        gr= gradient(lg_fun0(lgp)); 
        if RatRsq > RatRsq0 && gr(end)<1
            Rat_d = Ratp(4);
            Rat_k= Ratp(3);
            Rat_b= Ratp(2);
            Rat_Nf= Ratp(1);
            RatRsq0= RatRsq;
        end
        Ratp0=[5*mea_cases(end)*rand, 1000*rand, 50*rand, 0.5*rand];
    end
    Ratp(4)=Rat_d;
    Ratp(3)=Rat_k;
    Ratp(2)=Rat_b;
    Ratp(1)=Rat_Nf;
    Rat_fun= @(Ratp) Ratp(1)*(ones(nt,1)./(1+Ratp(2).*power((1+Ratp(4)*time),-Ratp(3))));
    plot(time, Rat_fun(Ratp),'c','LineWidth',1.5)
    hold off;

    disp('Goodness of fit tests for the Rational')
    [RatRsq, ~]= rsquare(mea_cases,Rat_fun(Ratp),5)
    % [h,p] = kstest2(mea_cases,Rat_fun(Ratp))
    RatRMSE = sqrt(mean((mea_cases - Rat_fun(Ratp)).^2)); 
    % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
    disp('Estimated parameters for the Rational')
    Rat_d = Ratp(4)		
    Rat_k= Ratp(3)
    Rat_b= Ratp(2)
    Rat_Nf= Ratp(1)

    header={'rational'};
    Results(:,4)= [header; num2cell(Rat_fun(Ratp))];
    Results(3,9)= [{'rational'}];    
    Results(3,10)= num2cell(RatRsq);
    Results(3,11)= num2cell(RatRMSE);
    Results(2,16)= [{'Nf'}];
    Results(3,16)= [{'b'}];
    Results(4,16)= [{'k'}];
    Results(5,16)= [{'d'}];
    Results(1,17)= [{'rational'}];
    Results(2:5,17)= num2cell(Ratp');
    
    writetable(cell2table(Results),'Results.xlsx','Sheet',string(cc),'WriteVariableNames',false)

    clear time mea_cases Results;

end


return;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 



